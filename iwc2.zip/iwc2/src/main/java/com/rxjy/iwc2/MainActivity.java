package com.rxjy.iwc2;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.rxjy.iwc2.database.ImageBean;
import com.rxjy.iwc2.service.BatteryService;
import com.rxjy.iwc2.service.CoreService;
import com.rxjy.iwc2.service.StorageManagerService;
import com.rxjy.iwc2.utils.TToast;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 先启动服务，在服务中进行网络请求，再回调进行拍照
 * <p/>
 * 单一职能原则：此处只进行动作识别检测
 * <p/>
 * Created by qindd on 2016/12/13.
 */
public class MainActivity extends Activity implements SurfaceHolder.Callback,
        Camera.PreviewCallback
{
    public static String TAG = "MainActivity";

    private Intent mCoreServiceIntent;
    private boolean mIsBind = false;
    private CoreService mCoreService;

    private TimerTask task;
    private Timer timer;

    private Camera mCamera;
    private Camera.Parameters parameters = null;
    private SurfaceView surfaceView;
    private boolean previewCallback = false;

    private Bitmap bitmap;// 原图
    private Bitmap savePicture; // 保存bitmap
    private Bitmap tempBitmap;// temp bitmap
    private Bitmap bitmap_;// 处理后的bitmap
    private Bitmap bgBitmap;// 背景图
    private Bitmap bgBitmap_;// 处理后的背景图片
    private long times = 0l;// 连续多久不动时间
    private long indexFrame = 0l;// 帧回调次数
    private long times_ = 0l;// temp time
    private int police_time = 10;// 确认障碍物开始(手机抖动)  //此处为了省电改成 3，默认10
    private int police_time_ = 3;// 确认障碍物              //此处为了省电改成 1，默认3
    private long times_2 = 0l;// 报警确认次数
//    private int Rgb = 200; // 阀值 动作识别灵敏度(初始1000)
    int i = 1;// 持续监测累加次数

    private Camera.Size cameraCalSize;

    private Camera.PictureCallback jpegCallback = new Camera.PictureCallback()
    {
        @Override
        public void onPictureTaken(byte[] data, Camera camera)
        {
            Log.i("MainActivity", "jpegCallback");
            Log.e("data.length:", data.length + "");
            if (camera.getParameters().getPictureFormat() == 256)
            {
                save(data); // 保存图片
                camera.startPreview();
            }
        }
    };

    // OpenCV库加载并初始化成功后的回调函数
    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this)
    {
        @Override
        public void onManagerConnected(int status)
        {
            switch (status)
            {
                case BaseLoaderCallback.SUCCESS:
                    Log.i(TAG, "OpenCV 成功加载");
                    previewCallback = true;
                    break;
                default:
                    super.onManagerConnected(status);
                    Log.i(TAG, "OpenCV 加载失败");
                    break;
            }
        }
    };


    private Camera.Size getPictureSize()
    {
        Camera.Size localSize = this.mCamera.getParameters().getPreviewSize();
        List localList = this.mCamera.getParameters().getSupportedPictureSizes();
        localSize.width = 0;
        localSize.height = 0;
        for (int j = 0; ; j++)
        {
            if (j >= localList.size())
                return localSize;
            int k = ((Camera.Size) localList.get(j)).width * ((Camera.Size) localList.get(j)).height;
            if (localSize.width * localSize.height < k)
                localSize = (Camera.Size) localList.get(j);
        }
    }

    private Camera.Size getPreviewSize()
    {
        Camera.Size localSize = this.mCamera.getParameters().getPreviewSize();
        List localList = this.mCamera.getParameters().getSupportedPreviewSizes();
        localSize.width = 0;
        localSize.height = 0;
        for (int j = 0; ; j++)
        {
            if (j >= localList.size())
                return localSize;
            int k = ((Camera.Size) localList.get(j)).width * ((Camera.Size) localList.get(j)).height;
            if (localSize.width * localSize.height < k)
                localSize = (Camera.Size) localList.get(j);
        }
    }

    public static TextView tv_flag;
    public static TextView tv_index;
    public static TextView tv_pic_count;
    public static TextView tv_rgb;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_flag = (TextView) findViewById(R.id.tv_flag);
        tv_pic_count = (TextView) findViewById(R.id.tv_pic_count);
        tv_rgb = (TextView) findViewById(R.id.tv_rgb);
        init();
    }

    private void init()
    {
        // 照相机预览的控件
        surfaceView = (SurfaceView) findViewById(R.id.surface_view);
        surfaceView.getHolder().addCallback(this);
        surfaceView.getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        surfaceView.getHolder().setFixedSize(176, 144); // 设置Surface分辨率
        surfaceView.getHolder().setKeepScreenOn(true);// 屏幕常亮
        // 唤醒屏幕并保持常亮
        wakeUpAndUnlock(this);
        // 启动服务
        mCoreServiceIntent = new Intent(this, CoreService.class);
        startCoreService();
        // 写一个服务用来删除多余照片
        startService(new Intent(this, StorageManagerService.class));
        // 启动电量服务
        startService(new Intent(this, BatteryService.class));
        // 开启定时任务
//      timerStart(15 * 1000);
    }

//    private String save(byte[] paramArrayOfByte)
//    {
//        String str = getInnerSDCardPath() + "/" + getTime() + ".jpg";
//        try {
//            if (Environment.getExternalStorageState().equals("mounted"))
//            {
//                File localFile = new File(str);
//                if (!localFile.exists())
//                    localFile.createNewFile();
//                FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
//                localFileOutputStream.write(paramArrayOfByte);
//                localFileOutputStream.close();
//            }
//            return str;
//        }
//        catch (Exception localException) {
//            localException.printStackTrace();
//        }
//        return null;
//    }

    @Override
    protected void onResume()
    {
        super.onResume();
        // load OpenCV engine and init OpenCV library
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_1_0, getApplicationContext(), mLoaderCallback);
        Log.i(TAG, "onResume() ==>> load OpenCV succeed.");
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        stopCoreService();

    }

    private void timerStart(final int requestRateTime)
    {
        timerStop();
        if (timer == null)
            timer = new Timer();
        if (task == null)
            task = new MainTask(requestRateTime, this);
        if (requestRateTime != 0)
        {
            timer.schedule(task, 20000, requestRateTime);
        } else
        {
            timer.schedule(task, 20000, 20000);
        }
    }

    private void timerStop()
    {
        if (task != null)
        {
            task.cancel();
            task = null;
        }
        if (timer != null)
        {
            timer.cancel();
            timer.purge();
            timer = null;
        }
    }

    public void startCoreService()
    {
        doBindService();
    }

    public void stopCoreService()
    {
        doUnbindService();
    }

    private void doBindService()
    {
        if (App.getCurProcessName(this).equals(getPackageName()))
        {
            bindService(mCoreServiceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
            mIsBind = true;
        }
    }

    private void doUnbindService()
    {
        if (mIsBind)
        {
            unbindService(serviceConnection);
            mIsBind = false;
        }
    }

    ServiceConnection serviceConnection = new ServiceConnection()
    {
        public void onServiceConnected(ComponentName name, IBinder service)
        {
            mCoreService = ((CoreService.CoreBinder) service).getService();
        }

        public void onServiceDisconnected(ComponentName name)
        {
            mCoreService = null;
        }
    };

    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {
        Log.e(TAG, "surfaceCreated();");
        try
        {
            mCamera = Camera.open(0); // 开启摄像头
            mCamera.setPreviewDisplay(holder);// 设置用于显示拍照影像的SurfaceHolder对象
            mCamera.setDisplayOrientation(getPreviewDegree(MainActivity.this));
            mCamera.startPreview(); // 开始预览
            cameraCalSize = getPictureSize();//获取保存图片最大size
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {
        Log.e(TAG, "surfaceChanged();");
        try
        {
            parameters = mCamera.getParameters();
            mCamera.setParameters(parameters);
            parameters.setPictureFormat(ImageFormat.JPEG); // 设置图片格式
            parameters.setPreviewSize(width, height); // 设置预览大小
            parameters.setPictureSize(width, height); // 设置保存的图片尺寸
            parameters.setJpegQuality(100); // 设置照片质量
            // 此处为自己添加
//            parameters.setFlashMode(Camera.Parameters.FLASH_MODE_AUTO);
//            parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            mCamera.setPreviewCallback(this);
            // 聚焦
//            startFocus();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {
        Log.e(TAG, "surfaceDestroyed();");
        if (mCamera != null)
        {
            mCamera.setPreviewCallback(null);
            mCamera.release(); // 释放照相机
            mCamera = null;
        }
    }

    private boolean isPreviewFrame = true;
    private Handler handler = new Handler();

    Runnable runnable = new Runnable()
    {
        @Override
        public void run()
        {
            isPreviewFrame = true;
        }
    };

    /**
     * Called as preview frames are displayed.  This callback is invoked
     * on the event thread was called from.
     */
    @Override
    public void onPreviewFrame(byte[] data, Camera camera)
    {
        if (isPreviewFrame)
        {
            // 动作识别(取模跳帧)
            if (indexFrame++ % 10 != 0) // 刷新次数逢6的倍数才往下执行，否则都return
                return;
            Camera.Size size = camera.getParameters().getPreviewSize();
//            Camera.Size size = camera.getParameters().getSupportedPictureSizes();
            try
            {
                YuvImage image = new YuvImage(data, ImageFormat.NV21, size.width, size.height, null);
                if (image != null)
                {
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    image.compressToJpeg(new Rect(0, 0, size.width, size.height), 100, stream);
                    // 得到bitmap
                    Bitmap bmp = BitmapFactory.decodeByteArray(stream.toByteArray(), 0, stream.size());
                    // **********************
                    // 因为图片会放生旋转，因此要对图片进行旋转到和手机在一个方向上
                    bmp = rotatingImageView(-270, bmp);
                    savePicture = bmp; // 为了保存原图
                    // 图片太大处理较慢，就把图片缩放裁剪
                    Matrix matrix = new Matrix();
                    matrix.postScale(0.125f, 0.125f); // 长和宽缩小的比例  (160 × 90), 实际上的像素点好像更少
//                  matrix.postScale(0.25f, 0.25f); // 长和宽缩小的比例  (160 × 90), 实际上的像素点好像更少
                    if (previewCallback == true)
                    {
                        bitmap = bmp.createBitmap(bmp, 0, 0, size.height, size.width, matrix, true);//创建图片
                        bitmap_ = procSrc2Gray(bitmap);// 灰度
                        bitmap_ = changeBitmap(bitmap);// 二值
                        // 识别
                        getPolice();
                    }
                    // **********************************
                    stream.close();
                }
            } catch (Exception ex)
            {
                Log.e("Sys", "Error:" + ex.getMessage());
            }
        } else
        {

        }
    }

    class MainTask extends TimerTask
    {
        int requestRateTime;
        int requestRateTimeNew;
        Context context;

        public MainTask(int requestRateTime, Context context)
        {
            this.requestRateTime = requestRateTime;
            this.context = context;
        }

        @Override
        public void run()
        {
            if (mCamera == null)
            {
                Log.e("MainTask", "MainTask---run()_1");
                mCamera = Camera.open(0); // 开启摄像头
                mCamera.setDisplayOrientation(getPreviewDegree(MainActivity.this));
                mCamera.startPreview(); // 开始预览
                Log.e("MainTask", "MainTask---run()_2");
            }
        }
    }

    // 自动对焦
    Timer focusTimer = new Timer(true);

    TimerTask focusTask = new TimerTask()
    {

        @Override
        public void run()
        {
            if (mCamera != null)
                mCamera.autoFocus(null);
        }
    };

    public void startFocus()
    {
        focusTimer.schedule(focusTask, 0, 7 * 1000);
    }

    // 提供一个静态方法，用于根据手机方向获得相机预览画面旋转的角度
    public static int getPreviewDegree(Activity activity)
    {
        // 获得手机的方向
        int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
        int degree = 0;
        // 根据手机的方向计算相机预览画面应该选择的角度
        switch (rotation)
        {
            case Surface.ROTATION_0:
                degree = 90;
                break;
            case Surface.ROTATION_90:
                degree = 0;
                break;
            case Surface.ROTATION_180:
                degree = 270;
                break;
            case Surface.ROTATION_270:
                degree = 180;
                break;
        }
        return degree;
    }

    // 旋转
    public Bitmap rotatingImageView(int angle, Bitmap bitmap)
    {
        // 旋转图片 动作
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        // 创建新的图片
        Bitmap bm = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return bm;
    }

    // 识别系统
    public void getPolice()
    {
        if (tempBitmap != null && times <= police_time)
        { // police_time = 10
            if (isEquals(tempBitmap, bitmap_) == true)
            {
                times++;
                times_2 = 0; // 确认报警次数
                if (times < police_time)
                {
                    Log.e(TAG, "number:持续不动次数" + times + ";");
                    App.displayToast(this, "持续不动" + times + "次");
                }
            } else if (isEquals(tempBitmap, bitmap_) == false && times > 0)
            {
                Log.e(TAG, "手机在动！");
                App.displayToast(this, "手机在动！");
                times_ = 0;
            }
        }

        if (tempBitmap != null && times < police_time)
        { // 重置times
            if (isEquals(tempBitmap, bitmap_) == false)
            {
                times = times_;
            }
        }

        tempBitmap = bitmap_;                   // 更新背景图
        if (times == police_time)
        {
            bgBitmap = bitmap;                  // 背景图
            bgBitmap_ = procSrc2Gray(bgBitmap); // 灰度
            bgBitmap_ = changeBitmap(bgBitmap); // 二值

            App.displayToast(this, "开始执行程序");
        }

        if (times > police_time)
        {
            //  有结果，则终止线程
            if (isEquals(bgBitmap_, bitmap_) == false)
            {
                times_2++; // 障碍物确认次数
                if (times_2 > 0)
                {
                    Log.e(TAG, "确认持续次数：" + times_2);
                    App.displayToast(this, "确认障碍物" + times_2 + "次");
                }
                if (times_2 > police_time_)
                { // police_time_ = 5
                    // 有结果，则终止线程
                    this.focusTimer.cancel();
                    times_2 = times_;// 确认之后清零，重新确认障碍物
                    // 保存图片
//                    saveBitmapToFile(savePicture);
                    times = 0;
                    police_time = 5;
                    isPreviewFrame = false;
                    handler.postDelayed(runnable, Constants.Interval_Time * 1000);
                    // 修改日期 2017/1/6 15:47
                    mCamera.takePicture(null, null, this.jpegCallback);
                    i++;
                    App.displayToast(this, "开始第" + i + "次检测");
                }
            } else
            {
                Log.e(TAG, "无障碍物！");
                times_2 = 0;
                App.displayToast(this, "无障碍物！");
            }
        }
    }

    // 比较图片
    public boolean isEquals(Bitmap b1, Bitmap b2)
    {
        int xCount = b1.getWidth();//获取x轴个数
        int yCount = b1.getHeight();//获取y轴个数
        int number = 0;
        for (int x = 0; x < xCount; x++)
        {
            for (int y = 0; y < yCount; y++)
            {
                // 比较每个像素点颜色
                if (b1.getPixel(x, y) != b2.getPixel(x, y))
                {
                    number++;
                }
            }
        }
        Log.e(TAG, "差异值：" + number);
        // displayToast("差异值："+ number);
        if (number < Constants.Rgb)
            return true;
        return false;
    }

    public boolean isEquals2(Bitmap b1, Bitmap b2)
    {
        int x = b1.getWidth();
        int y = b1.getHeight();
        int m = 0;
        int n = 0;
        if (n >= x)
        {
            Log.e("MainActivity", "差异值：" + m + ";总数：" + x * y);
            if (m < Constants.Rgb)
                return true;
        } else
        {
            for (int i1 = 0; ; i1++)
            {
                if (i1 >= y)
                {
                    n++;
                    break;
                }
                if (b1.getPixel(n, i1) != b2.getPixel(n, i1))
                    m++;
            }
        }
        return false;
    }

    // 灰度化
    public Bitmap procSrc2Gray(Bitmap bm)
    {
        Mat rgbMat = new Mat(); // 声明Mat 灰度化处理是不能用bitmap 得用mat
        Mat grayMat = new Mat();
        Mat mat = new Mat();
        Bitmap grayBmp = Bitmap.createBitmap(bm.getWidth(), bm.getHeight(), Bitmap.Config.ARGB_8888);
        Utils.bitmapToMat(bm, rgbMat);// convert original bitmap to Mat, R G B.bitmap转mat
        Imgproc.cvtColor(rgbMat, mat, Imgproc.COLOR_RGB2HLS);// 亮度
        Imgproc.cvtColor(rgbMat, grayMat, Imgproc.COLOR_RGB2GRAY);// 灰度化方法
        Utils.matToBitmap(mat, grayBmp);
        return grayBmp;
    }

    // 二值化
    public Bitmap changeBitmap(Bitmap bm)
    {
        Mat rgbMat = new Mat();
        Mat grayMat = new Mat();
        Bitmap grayBmp = Bitmap.createBitmap(bm.getWidth(), bm.getHeight(), Bitmap.Config.ARGB_8888);
        Utils.bitmapToMat(bm, rgbMat);
        Imgproc.threshold(rgbMat, grayMat, 100, 255, Imgproc.THRESH_BINARY);
        Utils.matToBitmap(grayMat, grayBmp);
        return grayBmp;
    }

    // 储存图片
    public void save(byte[] data)
    {

        File picFile = new File(Constants.DEFAULT_SAVE_IMAGE_PATH_PARENT);
        picFile = new File(picFile, "iwc_img2");
        if (!picFile.exists() && !picFile.mkdirs())
        {
            TToast.showL(MainActivity.this, "无法创建日期文件夹");
            return;
        }
        String photoName = getSimpleTime() + ".jpg";
        String photoPath = "";
        if (picFile != null)
        {
            photoPath = picFile.getPath() + File.separator + photoName;
        }
        try
        {
            FileOutputStream fos = new FileOutputStream(photoPath);
            fos.write(data);
            fos.close();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        ImageBean imgBean = new ImageBean();
        imgBean.setName(photoName);
        imgBean.setPath(photoPath);
        imgBean.setTime(getSimpleTime());
        imgBean.setRescode(Constants.NOT_UPLOAD); // 0
        App.getInstance().imgDB.insert(imgBean);

        // 发送广播，在service中接受广播

    }

    public String getSimpleTime()
    {
        String time = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        return time;
    }

    //解锁
    private void wakeUpAndUnlock(Context context)
    {
        KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
        KeyguardManager.KeyguardLock kl = km.newKeyguardLock("unLock");
        //解锁
        kl.disableKeyguard();
        //获取电源管理器对象
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        //获取PowerManager.WakeLock对象,后面的参数|表示同时传入两个值,最后的是LogCat里用的Tag
        PowerManager.WakeLock mWakeLock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.SCREEN_DIM_WAKE_LOCK, "bright");
        //点亮屏幕
        mWakeLock.acquire();
    }

}
