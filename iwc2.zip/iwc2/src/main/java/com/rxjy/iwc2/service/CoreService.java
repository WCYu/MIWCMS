package com.rxjy.iwc2.service;

import android.app.Service;
import android.content.Intent;
import android.net.wifi.WifiConfiguration;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.Nullable;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.rxjy.iwc2.App;
import com.rxjy.iwc2.Constants;
import com.rxjy.iwc2.MainActivity;
import com.rxjy.iwc2.database.ImageBean;
import com.rxjy.iwc2.nohttp.HttpListener;
import com.rxjy.iwc2.nohttp.IWCHttp;
import com.rxjy.iwc2.update.UpdateManager;
import com.rxjy.iwc2.utils.ImageUtils;
import com.rxjy.iwc2.utils.NetUtils;
import com.rxjy.iwc2.utils.SHA;
import com.rxjy.iwc2.utils.SPUtil;
import com.rxjy.iwc2.utils.StringUtils;
import com.rxjy.iwc2.wifi.WifiAdmin;
import com.yolanda.nohttp.Headers;
import com.yolanda.nohttp.rest.Response;
import com.yolanda.nohttp.tools.HeaderParser;
import com.yolanda.nohttp.tools.IOUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by qindd on 2016/12/13.
 */
public class CoreService extends Service implements HttpListener
{
    public static String TAG = "CoreService";
    private Timer httpRequestTimer;
    private HttpRequestTask httpRequestTask;

    Handler handler = new Handler()
    {

        @Override
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);
            switch (msg.arg1)
            {
                case UpdateManager.UPDATE_COMPLETE:
                    UpdateManager.silentInstall();
                    break;
                default:
                    break;
            }
        }
    };

    private final IBinder mBinder = new CoreBinder();

    public class CoreBinder extends Binder
    {
        public CoreService getService()
        {
            return CoreService.this;
        }
    }

//    protected AsyncHttpResponseHandler mHandler = new AsyncHttpResponseHandler()
//    {
//        @Override
//        public void onSuccess(int statusCode, Header[] headers, byte[] responseBytes)
//        {
//            String result = "";
//            if (responseBytes != null && responseBytes.length != 0)
//            {
//                result = new String(responseBytes);
//            }
//            JSONObject jsonObject;
//            try
//            {
//                jsonObject = new JSONObject(result);
//                int resCode = jsonObject.getInt("StatusCode");
//                if (resCode == 1)
//                {
//                    // 启动上传照片定时任务(只启动一次)
//                    if (!isUploadStartTimer)
//                    {
////                        startUploadTimer(timeSpan * 1000);
////                        isUploadStartTimer = true;
//                        readyToUpload();
//                    }
//                    // 解析json
//                    parseFromJson(new String(responseBytes));
//                    // 检测版本更新
//                    if (UpdateManager.isUpdate(CoreService.this))
//                    {
//                        UpdateManager.downloadApk(Constants.ApkPath, handler);
//                    }
//                } else if (resCode == 0)
//                {
//                    Log.e(TAG, "isDeviceOnline...onSuccess...");
//                    if (!isUploadStartTimer)
//                    {
//                        startUploadTimer(timeSpan * 1000);
//                        isUploadStartTimer = true;
//                    }
//                } else if (resCode == 107)
//                {
//                    // 停止拍照
//                }
//            } catch (JSONException e)
//            {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        public void onFailure(int statusCode, Header[] headers, byte[] responseBytes, Throwable throwable)
//        {
//            if (responseBytes != null && responseBytes.length != 0)
//            {
//
//            } else
//            {
//
//            }
//        }
//    };

    @Override
    public void onCreate()
    {
        init();
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        return super.onStartCommand(intent, flags, startId);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent)
    {
        Log.e(TAG, "onBind");
        return mBinder;
    }

    @Override
    public void onRebind(Intent intent)
    {
        Log.e(TAG, "onRebind");
        super.onRebind(intent);
    }

    @Override
    public boolean onUnbind(Intent intent)
    {
        Log.e(TAG, "onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy()
    {
        Log.e(TAG, "onDestroy");
        super.onDestroy();
        stopTimer();
    }

    private void init()
    {
        if (!NetUtils.isWiFiConnected(App.getInstance()))
            connectWifi();

        if (isFirstRun()) // 首次启动
        {
            // 从属性文件读取数据
            Properties props = App.getProps(this);
            if (props != null)
            {
                Constants.ConfVerCode = props.getProperty("ConfVerCode", "0.0");
                Constants.Nact_Time = StringUtils.toInt(props.getProperty("Nact_Time"));
                Constants.Act_Time = StringUtils.toInt(props.getProperty("Act_Time"));
                Constants.Interval_Time = StringUtils.toInt(props.getProperty("Interval_Time"));
                Constants.Low_Power = StringUtils.toInt(props.getProperty("Low_Power"));
                Constants.Nnet_Time = StringUtils.toInt(props.getProperty("Nnet_Time"));
                Constants.Img_Level = StringUtils.toInt(props.getProperty("Img_Level"));
                Constants.ImgSave_Time = StringUtils.toInt(props.getProperty("ImgSave_Time"));
                Constants.Check_OL_Time = StringUtils.toInt(props.getProperty("Check_OL_Time", "60"));
                Constants.SSID = props.getProperty("SSID");
                Constants.PassWord = props.getProperty("PassWord");
                Constants.SubItemId = props.getProperty("SubItemId");
                Constants.Low_Power_Failure_Count = StringUtils.toInt(props.getProperty("Low_Power_Failture_Count"));
                Constants.Low_Power_Point = StringUtils.toInt(props.getProperty("Low_Power_Point"));
                Constants.UploadPic_Failure_Count = StringUtils.toInt(props.getProperty("UploadPic_Failture_Count"));
                Constants.Rgb = StringUtils.toInt(props.getProperty("Rgb"));

                SPUtil.put(App.getInstance(), "ConfVerCode", Constants.ConfVerCode);
                SPUtil.put(App.getInstance(), "Nact_Time", Constants.Nact_Time);
                SPUtil.put(App.getInstance(), "Act_Time", Constants.Act_Time);
                SPUtil.put(App.getInstance(), "Interval_Time", Constants.Interval_Time);
                SPUtil.put(App.getInstance(), "Low_Power", Constants.Low_Power);
                SPUtil.put(App.getInstance(), "Nnet_Time", Constants.Nnet_Time);
                SPUtil.put(App.getInstance(), "Img_Level", Constants.Img_Level);
                SPUtil.put(App.getInstance(), "ImgSave_Time", Constants.ImgSave_Time);
                SPUtil.put(App.getInstance(), "Check_OL_Time", Constants.Check_OL_Time);
                SPUtil.put(App.getInstance(), "SSID", Constants.SSID);
                SPUtil.put(App.getInstance(), "PassWord", Constants.PassWord);
                SPUtil.put(App.getInstance(), "SubItemId", Constants.SubItemId);
                SPUtil.put(App.getInstance(), "Low_Power_Failture_Count", Constants.Low_Power_Failure_Count);
                SPUtil.put(App.getInstance(), "Low_Power_Point", Constants.Low_Power_Point);
                SPUtil.put(App.getInstance(), "UploadPic_Failture_Count", Constants.UploadPic_Failure_Count);
                SPUtil.put(App.getInstance(), "Rgb", Constants.Rgb);
                SPUtil.put(App.getInstance(), "ElectricityNumber", Constants.ElectricityNumber);
            }
        } else
        {
            Constants.ConfVerCode = (String) SPUtil.get(App.getInstance(), "ConfVerCode", "0.0");
            Constants.Nact_Time = (int) SPUtil.get(App.getInstance(), "Nact_Time", 600);
            Constants.Act_Time = (int) SPUtil.get(App.getInstance(), "Act_Time", 60);
            Constants.Interval_Time = (int) SPUtil.get(App.getInstance(), "Interval_Time", 600);
            Constants.Low_Power = (int) SPUtil.get(App.getInstance(), "Low_Power", 30);
            Constants.Nnet_Time = (int) SPUtil.get(App.getInstance(), "Nnet_Time", 300);
            Constants.Img_Level = (int) SPUtil.get(App.getInstance(), "Img_Level", 1);
            Constants.ImgSave_Time = (int) SPUtil.get(App.getInstance(), "ImgSave_Time", 1);
            Constants.Check_OL_Time = (int) SPUtil.get(App.getInstance(), "Check_OL_Time", 60);
            Constants.SSID = (String) SPUtil.get(App.getInstance(), "SSID", "rxjy");
            Constants.PassWord = (String) SPUtil.get(App.getInstance(), "PassWord", "rxjy@123");
            Constants.SubItemId = (String) SPUtil.get(App.getInstance(), "SubItemId", "");
            Constants.Low_Power_Failure_Count = (int) SPUtil.get(App.getInstance(), "Low_Power_Failure_Count", 3);
            Constants.Low_Power_Point = (int) SPUtil.get(App.getInstance(), "Low_Power_Point", 10);
            Constants.UploadPic_Failure_Count = (int) SPUtil.get(App.getInstance(), "UploadPic_Failure_Count", 3);
            Constants.VersionCode = (int) SPUtil.get(App.getInstance(), "VersionCode", 0);
            Constants.downloadApk = (String) SPUtil.get(App.getInstance(), "ApkPath", "");
            Constants.Rgb = (int) SPUtil.get(App.getInstance(), "Rgb", 200);
            Constants.ElectricityNumber = (String) SPUtil.get(App.getInstance(), "ElectricityNumber", "");
        }
		Constants.IMEI = getIMEI();
//        Constants.IMEI = "867282050070096";        // 0096

        startTimer(StringUtils.toInt(Constants.Check_OL_Time) * 1000);
    }

    private void startTimer(int periodTime)
    {
        stopTimer();
        if (httpRequestTimer == null)
            httpRequestTimer = new Timer();
        if (httpRequestTask == null)
            httpRequestTask = new HttpRequestTask(periodTime);

        httpRequestTimer.schedule(httpRequestTask, 1000, periodTime);

//        if(periodTime != 0){
//            if(isfirstCome){
//                httpRequestTimer.schedule(httpRequestTask, 5000, periodTime);
//            }else{
//                httpRequestTimer.schedule(httpRequestTask, periodTime, periodTime);
//            }
//        }
    }

    private void stopTimer()
    {
        if (httpRequestTimer != null)
        {
            httpRequestTimer.cancel();
            httpRequestTimer.purge();
            httpRequestTimer = null;
        }
        if (httpRequestTask != null)
        {
            httpRequestTask.cancel();
            httpRequestTask = null;
        }
    }

    class HttpRequestTask extends TimerTask
    {
        int requestRateTime;
        int requestRateTimeNew;

        public HttpRequestTask(int requestRateTime)
        {
            this.requestRateTime = requestRateTime;
        }

        @Override
        public void run()
        {
            String timeStamp = getTimeStamp();
            // 假 IMEI
//            String value = "ConfVerCode" + Constants.ConfVerCode + "IMEI" + Constants.IMEI + "timeStamp" + timeStamp;
            // 真 IMEI
            String value = "ConfVerCode" + Constants.ConfVerCode + "IMEI" + getIMEI() + "timeStamp" + timeStamp;
            StringBuilder sb = new StringBuilder();
            sb.append(Constants.apiKey).append(value).append(Constants.apiSecret);
            value = sb.toString();
            if(NetUtils.isWiFiConnected(CoreService.this)){
                // 网络请求
                IWCHttp.IsDeviceOnline(CoreService.this, Constants.apiKey, SHA.SHA1(value), timeStamp,
                        Constants.IMEI, Constants.ConfVerCode, Constants.ElectricityNumber, CoreService.this);
                Log.e(TAG, "isDeviceOnline...run...");
            }else {
                connectWifi();
            }
            requestRateTimeNew = StringUtils.toInt(Constants.Check_OL_Time);
            if (requestRateTime / 1000 != requestRateTimeNew)
            {
                startTimer(requestRateTimeNew * 1000);
            }

            //----------------------------------------我是分割线------------------------------------------

//            String timeStamp = getTimeStamp();
//            // 假 IMEI
//            String value = "ConfVerCode" + Constants.ConfVerCode + "IMEI" + Constants.IMEI + "timeStamp" + timeStamp;
//            // 真 IMEI
////            String value = "ConfVerCode" + Constants.ConfVerCode + "IMEI" + getIMEI() + "timeStamp" + timeStamp;
//            StringBuilder sb = new StringBuilder();
//            sb.append(Constants.apiKey).append(value).append(Constants.apiSecret);
//            value = sb.toString();
//            // 网络请求
//            IWCApi.IsDeviceOnline(Constants.IsDeviceOnline, Constants.apiKey,
//                    SHA.SHA1(value), timeStamp, Constants.IMEI, Constants.ConfVerCode, mHandler);
//
//            Log.e(TAG, "isDeviceOnline...run...");
//
//            requestRateTimeNew = StringUtils.toInt(Constants.Check_OL_Time);
//            if (requestRateTime / 1000 != requestRateTimeNew)
//            {
//                startTimer(requestRateTimeNew * 1000);
//            }
        }
    }

    private void connectWifi()
    {
        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                WifiAdmin wAdmin = new WifiAdmin(CoreService.this);
                wAdmin.openWifi();
                wAdmin.startScan();//要调用这个方法，连接wifi才不会出错
                WifiConfiguration wifiConfig = wAdmin.CreateWifiInfo(Constants.SSID, Constants.PassWord, Constants.Type);
                wAdmin.addNetwork(wifiConfig);
            }
        }).start();
    }

    // 程序第一次启动
    private boolean isFirstRun()
    {
        boolean isFirstRun = (Boolean) SPUtil.get(App.getInstance(), "isFirstRun", true);

        if (!isFirstRun)
        {
            return false;
        } else
        {
            SPUtil.put(App.getInstance(), "isFirstRun", false);
            return true;
        }
    }

    private String getIMEI()
    {
        TelephonyManager teleManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        String imei = teleManager.getDeviceId();
        return imei;
    }

    // 时间戳
    private String getTimeStamp()
    {
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        return timeStamp;
    }

    // 解析json
    private void parseFromJson(String json)
    {
        if (!"".equals(json) && json != null)
        {
            JSONObject jsonObject;
            try
            {
                jsonObject = new JSONObject(json);
                jsonObject = jsonObject.getJSONObject("Body");
                if (jsonObject != null)
                {
                    Constants.ConfVerCode = jsonObject.get("ConfVerCode") != null ? (String) jsonObject.get("ConfVerCode") : "";
                    Constants.Nact_Time = jsonObject.getInt("Nact_Time") != 0 ? jsonObject.getInt("Nact_Time") : 100;
                    Constants.Act_Time = jsonObject.getInt("Act_Time") != 0 ? jsonObject.getInt("Act_Time") : 100;
                    Constants.Interval_Time = jsonObject.getInt("Interval_Time") != 0 ? jsonObject.getInt("Interval_Time") : 600;
                    Constants.Low_Power = jsonObject.getInt("Low_Power") != 0 ? jsonObject.getInt("Low_Power") : 30;
                    Constants.Nnet_Time = jsonObject.getInt("Nnet_Time") != 0 ? jsonObject.getInt("Nnet_Time") : 300;
                    Constants.Img_Level = jsonObject.getInt("Img_Level") != 0 ? jsonObject.getInt("Img_Level") : 1;
                    Constants.ImgSave_Time = jsonObject.getInt("ImgSave_Time") != 0 ? jsonObject.getInt("ImgSave_Time") : 1;
                    Constants.Check_OL_Time = jsonObject.getInt("Check_OL_Time") != 0 ? jsonObject.getInt("Check_OL_Time") : 60;
                    Constants.SSID = jsonObject.get("SSID") != null ? (String) jsonObject.get("SSID") : "";
                    Constants.PassWord = jsonObject.get("PassWord") != null ? (String) jsonObject.get("PassWord") : "";
                    Constants.SubItemId = jsonObject.get("SubItemId") != null ? (String) jsonObject.get("SubItemId") : "";
                    Constants.Low_Power_Failure_Count = jsonObject.getInt("Low_Power_Failure_Count") != 0 ? jsonObject.getInt("Low_Power_Failure_Count") : 3;
                    Constants.Low_Power_Point = jsonObject.getInt("Low_Power_Point") != 0 ? jsonObject.getInt("Low_Power_Point") : 10;
                    Constants.UploadPic_Failure_Count = jsonObject.getInt("UploadPic_Failure_Count") != 0 ? jsonObject.getInt("UploadPic_Failure_Count") : 3;
                    Constants.VersionCode = jsonObject.getInt("VersionCode");
                    Constants.IsTakePicture = jsonObject.getInt("IsTakePicture");
                    Constants.ApkPath = jsonObject.get("ApkPath") != null ? (String) jsonObject.get("ApkPath") : "";
                    Constants.Rgb = jsonObject.getInt("Rgb") != 0 ? jsonObject.getInt("Rgb") : 0;
                    Constants.ElectricityNumber = jsonObject.get("ElectricityNumber") != null ? (String) jsonObject.get("ElectricityNumber") : "";

                    SPUtil.put(App.getInstance(), "ConfVerCode", Constants.ConfVerCode);
                    SPUtil.put(App.getInstance(), "Nact_Time", Constants.Nact_Time);
                    SPUtil.put(App.getInstance(), "Act_Time", Constants.Act_Time);
                    SPUtil.put(App.getInstance(), "Interval_Time", Constants.Interval_Time);
                    SPUtil.put(App.getInstance(), "Low_Power", Constants.Low_Power);
                    SPUtil.put(App.getInstance(), "Nnet_Time", Constants.Nnet_Time);
                    SPUtil.put(App.getInstance(), "Img_Level", Constants.Img_Level);
                    SPUtil.put(App.getInstance(), "ImgSave_Time", Constants.ImgSave_Time);
                    SPUtil.put(App.getInstance(), "Check_OL_Time", Constants.Check_OL_Time);
                    SPUtil.put(App.getInstance(), "SSID", Constants.SSID);
                    SPUtil.put(App.getInstance(), "PassWord", Constants.PassWord);
                    SPUtil.put(App.getInstance(), "SubItemId", Constants.SubItemId);
                    SPUtil.put(App.getInstance(), "Low_Power_Failure_Count", Constants.Low_Power_Failure_Count);
                    SPUtil.put(App.getInstance(), "Low_Power_Point", Constants.Low_Power_Point);
                    SPUtil.put(App.getInstance(), "UploadPic_Failure_Count", Constants.UploadPic_Failure_Count);
                    SPUtil.put(App.getInstance(), "VersionCode", Constants.VersionCode);
                    SPUtil.put(App.getInstance(), "IsTakePicture", Constants.IsTakePicture);
                    SPUtil.put(App.getInstance(), "ApkPath", Constants.ApkPath);
                    SPUtil.put(App.getInstance(), "Rgb", Constants.Rgb);
                    SPUtil.put(App.getInstance(), "ElectricityNumber", Constants.ElectricityNumber);

                    MainActivity.tv_rgb.setText("rgb:" + Constants.Rgb);
//                    if(Constants.IsTakePicture != 1)
//                    {
//                        mIsCameraStop = true;
//                        EventBus.getDefault().post(new UploadIntervalTimeEvent(200));
//                    }
//                    if(Constants.IsTakePicture == 1)
//                    {
//                        mIsCameraStop = false;
//                        EventBus.getDefault().post(new UploadIntervalTimeEvent(201));
//                    }
                } else
                {

                }
            } catch (JSONException e)
            {
                e.printStackTrace();
            }
        }
    }

    /**
     * -------------------------- 上传照片的定时任务 --------------------------
     */
    public static List<ImageBean> imageBeanList = new ArrayList<>();
    private String uploadSuccessPath; // 这条路径是用来删除数据库中的数据的

//    private boolean ongoingFlag = false; // 照片上传是否进行中

//    int formerCount = -1;
//    int currentCount = 0;
    int index = 0;

    // 上传照片
    private void uploadPicRequest()
    {
//        MainActivity.tv_flag.setText("flag状态:" + "true");
        String photoPath = "";
        // 查询数据库，得到需要上传的图片路径，封装成一个list
        imageBeanList = App.getInstance().imgDB.query(Constants.NOT_UPLOAD);
        if (imageBeanList != null && imageBeanList.size() != 0)
        {
            uploadSuccessPath = photoPath = imageBeanList.get(0).getPath();

            String timeStamp = getTimeStamp();
            String value = "IMEI" + Constants.IMEI + "SubItemId" + Constants.SubItemId + "timeStamp" + timeStamp;
            StringBuilder sb = new StringBuilder();
            sb.append(Constants.apiKey).append(value).append(Constants.apiSecret);
            value = sb.toString();
            String pic_base64 = "";
            if (!"".equals(photoPath))
            {
                pic_base64 = ImageUtils.bitmapToString(photoPath, StringUtils.toInt(Constants.Img_Level));
            }
            IWCHttp.UploadPicture(this, Constants.apiKey, SHA.SHA1(value), timeStamp,
                    Constants.IMEI, Constants.SubItemId, pic_base64, this);
//            ongoingFlag = true;
        }
    }


    @Override
    public void onSucceed(int what, Response response)
    {
        String responseStr = IOUtils.toString(response.getByteArray(),
                HeaderParser.parseHeadValue(response.getHeaders().getContentType(),
                        Headers.HEAD_KEY_CONTENT_TYPE, ""));
        if (what == Constants.ACTION_IS_DEVICE_ONLINE)
        {
            JSONObject jsonObject;
            try
            {
                jsonObject = new JSONObject(responseStr);
                int resCode;
                resCode = jsonObject.getInt("StatusCode");
                if (resCode == 1)
                {
//                    if (ongoingFlag == false)
//                        uploadPicRequest();
                    // 解析json
                    parseFromJson(responseStr);
                    // 检测版本更新
                    if (UpdateManager.isUpdate(this))
                    {
                        UpdateManager.downloadApk(Constants.ApkPath, handler);
                    }
                } else if (resCode == 0)
                {
                    uploadPicRequest();
//                    imageBeanList = App.getInstance().imgDB.query(Constants.NOT_UPLOAD);
//                    currentCount = imageBeanList.size();
//                    MainActivity.tv_flag.setText("flag状态:" + ongoingFlag);
//                    MainActivity.tv_pic_count.setText("剩余照片上传张数：" + imageBeanList.size());
//                    MainActivity.tv_rgb.setText("rgb:" + Constants.Rgb);
//                    if(imageBeanList.size() > 0){
//                        if (formerCount == currentCount)
//                        {
//                            index++;
//                        } else
//                        {
//                            index = 0;
//                        }
//                        if(index > 2){
//                            ongoingFlag = false;
//                            index = 0;
//                        }
//                        formerCount = currentCount;
//                    }
//                    if (ongoingFlag == false)
//                        uploadPicRequest();
                } else if (resCode == 107)
                {
                    // 停止拍照
                }
            } catch (JSONException e)
            {
                e.printStackTrace();
            }
        }

        if (what == Constants.ACTION_UPLOAD_PICTURE)
        {
            JSONObject jsonObject;
            try
            {
                jsonObject = new JSONObject(responseStr);
                int resCode;
                resCode = jsonObject.getInt("StatusCode");
                if (resCode == 0)
                {
                    App.getInstance().imgDB.delete(uploadSuccessPath);
//                    imageBeanList = App.getInstance().imgDB.query(Constants.NOT_UPLOAD);
//                    if (imageBeanList.size() == 0){
//                        ongoingFlag = false;
//                        index = 0;
//                    }
//                    else {
//                        uploadPicRequest();
//                    }
                }else{
//                    ongoingFlag = false;
                }
            } catch (JSONException e)
            {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailed(int what, String url, Object tag, CharSequence message, int responseCode, long networkMillis)
    {
//        ongoingFlag = false;
//        MainActivity.tv_flag.setText("flag状态:" + "false");
    }

}
