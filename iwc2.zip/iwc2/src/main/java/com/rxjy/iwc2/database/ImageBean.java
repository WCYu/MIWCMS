package com.rxjy.iwc2.database;

public class ImageBean
{

	private int id;
	private String name;
	private String time;
	private String path;
	private int rescode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public int getRescode() {
		return rescode;
	}

	public void setRescode(int rescode) {
		this.rescode = rescode;
	}

}
