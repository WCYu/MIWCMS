package com.rxjy.iwc2.interfaces;

/**
 * Created by qindd on 2017/1/11.
 */
public interface OnDetectedListener
{
    void onDetected(String pathStr);
}
