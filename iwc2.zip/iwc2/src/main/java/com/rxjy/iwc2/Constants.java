package com.rxjy.iwc2;

import android.os.Environment;

import java.io.File;

/**
 * Created by qindd on 2016/12/13.
 */
public class Constants
{

//	public static final String JRZN_URL = "http://api.jingrenzn.com:8083/";
//	public static final String JRZN_URL = "http://test4.rxjy.com:8004/";

//    public static final String JRZN_LOCAL_URL = "http://10.10.13.43:8095/";
    public static final String JRZN_LOCAL_URL = "http://192.168.1.230:801/";


    private final static String APP_CONFIG = "config";

    public static String IMEI;
    public static String ConfVerCode;
    public static int Nact_Time;
    public static int Act_Time;
    public static int Interval_Time; // 拍摄间隔
    public static int Low_Power;
    public static int Low_Power_Failure_Count; // 电量过低首次上传失败后再次上传的次数 3
    public static int Low_Power_Point = 5; // 百分点间隔 5
    public static int UploadPic_Failure_Count; // 拍照失败后再次上传次数
    //	public static String UploadPic_Failure_Time; // 拍照失败后再次上传时间间隔
    public static int Nnet_Time;
    public static int Img_Level;
    public static int ImgSave_Time;
    public static int Check_OL_Time;
    public static String SSID;
    public static String PassWord;
    public static String SubItemId;
    public static int VersionCode;
    public static int IsTakePicture;
    public static String ElectricityNumber; // 电量值，2017/4/26新增字段
    public static String ApkPath;
    public static int Rgb; // 动作识别灵敏度
    public static int Type = 3;//WPA或WPA2 PSK密码验证

    public static String apiKey = "rxjy@123";
    public static String apiSecret = "IWCS@456";

    public static final String IsDeviceOnline = JRZN_LOCAL_URL + "api/ParameterConfiguration/IsDeviceOnline";
    public static final String UploadPicture  = JRZN_LOCAL_URL + "api/ParameterConfiguration/UploadPicture";
    public static final String IsLowPower 	  = JRZN_LOCAL_URL + "api/ParameterConfiguration/IsLowPower";
    public static final String SendErrorMsg   = JRZN_LOCAL_URL + "api/ParameterConfiguration/SendErrorMsg";
    public static String downloadApk 		  = JRZN_LOCAL_URL + "api/ParameterConfiguration/DownloadAPK";

//	public static final String IsDeviceOnline = JRZN_URL + "api/ParameterConfiguration/IsDeviceOnline";
//	public static final String UploadPicture  = JRZN_URL + "api/ParameterConfiguration/UploadPicture";
//	public static final String IsLowPower 	  = JRZN_URL + "api/ParameterConfiguration/IsLowPower";
//	public static final String SendErrorMsg   = JRZN_URL + "api/ParameterConfiguration/SendErrorMsg";
//	public static String downloadApk 		  = JRZN_URL + "api/ParameterConfiguration/DownloadAPK";

    public static final int baseRequest = 100;

    public static final int ACTION_IS_DEVICE_ONLINE = baseRequest + 1;
    public static final int ACTION_UPLOAD_PICTURE= baseRequest + 2;
    public static final int ACTION_IS_LOW_POWER = baseRequest + 3;

    public static final int NOT_UPLOAD = 0;
    public static final int UPLOAD_SUCCEED = 1;
//    public static final int UPLOAD_FAILED = -1;

    public final static String DEFAULT_SAVE_IMAGE_PATH_PARENT = Environment
            .getExternalStorageDirectory()
            + File.separator
            + "IWC"
            + File.separator;

    public final static String DEFAULT_SAVE_IMAGE_PATH = Environment
            .getExternalStorageDirectory()
            + File.separator
            + "IWC"
            + File.separator + "iwc_img";

    public final static String DEFAULT_SAVE_IMAGE_PATH2 = Environment
            .getExternalStorageDirectory()
            + File.separator
            + "IWC"
            + File.separator + "iwc_img";

    public final static String DEFAULT_SAVE_FILE_PATH = Environment
            .getExternalStorageDirectory()
            + File.separator
            + "IWC"
            + File.separator + "download" + File.separator;


}
